package interfaces.impl;

import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.model.CreateTableRequest;

import module.DynamodbTableConfig;
import interfaces.DynamodbTableService;

public class DynamodbTableServiceImpl implements DynamodbTableService {
	static DynamoDB dynamoDB = new DynamoDB(new AmazonDynamoDBClient(
            new ProfileCredentialsProvider()));
	
	@Override
	public Table createTable(DynamodbTableConfig config) {
		return dynamoDB.createTable(new CreateTableRequest().withTableName(config.getTableName()).withKeySchema(config.getSchema()));
	}

}

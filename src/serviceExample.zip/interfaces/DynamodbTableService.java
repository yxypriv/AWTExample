package interfaces;

import com.amazonaws.services.dynamodbv2.document.Table;

import module.DynamodbTableConfig;

public interface DynamodbTableService {
	Table createTable(DynamodbTableConfig config);
}
